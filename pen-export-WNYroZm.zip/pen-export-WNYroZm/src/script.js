
// Função para exibir uma mensagem de acordo com a resposta selecionada
function exibirMensagem(resposta) {
  if (resposta === 'sim') {
    alert('Que ótimo! tudo vai ficar bem por aceitar mudar por nós. Juntos, faremos coisas incríveis!');
  } else if (resposta === 'nao') {
    alert('Lamento que você não esteja disposto a mudar por nós. Esperamos que você possa reconsiderar.');
  } else {
    alert('Por favor, selecione uma opção válida (Sim ou Não).');
  }
}